import requests
import hashlib

# ✅ Tus credenciales reales
API_LOGIN = "Q10SI1l819l1Rbl"
API_KEY = "F5XwOiBeHGVJXnmzg5otfjzY7S"
MERCHANT_ID = "1024716"
ACCOUNT_ID = "1033875"

def generar_firma(api_key, merchant_id, reference_code, amount, currency):
    raw = f"{api_key}~{merchant_id}~{reference_code}~{amount:.1f}~{currency}"
    return hashlib.md5(raw.encode()).hexdigest()

reference_code = "pedido001"
amount = 1.0
currency = "USD"
firma = generar_firma(API_KEY, MERCHANT_ID, reference_code, amount, currency)

payload = {
    "language": "es",
    "command": "SUBMIT_TRANSACTION",
    "merchant": {
        "apiLogin":"Q10SI1l819l1Rbl"
        "apiKey":"F5XwOiBeHGVJXnmzg5otfjzY7S"
    },
    "transaction": {
        "order": {
            "accountId": ACCOUNT_ID,
            "referenceCode": reference_code,
            "description": "Pago automático de prueba",
            "language": "es",
            "signature": firma,
            "notifyUrl": "http://tusitio.com/notificacion",
            "additionalValues": {
                "TX_VALUE": {
                    "value": amount,
                    "currency": currency
                }
            },
            "buyer": {
                "fullName": "Juan Pérez",
                "emailAddress": "juan@email.com",
                "contactPhone": "3001234567",
                "dniNumber": "123456789",
                "shippingAddress": {
                    "street1": "Calle 123",
                    "city": "Bogotá",
                    "state": "Cundinamarca",
                    "country": "CO"
                }
            }
        },
        "payer": {
            "fullName": "Juan Pérez",
            "emailAddress": "juan@email.com"
        },
        "creditCard": {
            "number": "4111111111111111",
            "securityCode": "123",
            "expirationDate": "2025/12",
            "name": "Juan Pérez"
        },
        "extraParameters": {
            "INSTALLMENTS_NUMBER": 1
        },
        "type": "AUTHORIZATION_AND_CAPTURE",
        "paymentMethod": "VISA",
        "paymentCountry": "CO",
        "deviceSessionId": "abc123",
        "ipAddress": "127.0.0.1",
        "cookie": "cookie_test",
        "userAgent": "Python/requests"
    },
    "test": True
}

url = "https://sandbox.api.payulatam.com/payments-api/4.0/service.cgi"
response = requests.post(url, json=payload)
print(response.json())
